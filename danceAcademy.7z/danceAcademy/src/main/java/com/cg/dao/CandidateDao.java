package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.beans.Candidate;

@Repository

public interface CandidateDao extends JpaRepository<Candidate, Integer> {

	
//	@PersistenceContext
//	EntityManager entitymanager;
//
//	@Override
//	public boolean signUp(Candidate candidate) {
//		// TODO Auto-generated method stub
//		System.out.println("Dao");
//		entitymanager.persist(candidate);
//		return true;
//	}

}
