package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Candidate;
import com.cg.beans.Choreographer;
import com.cg.dao.ChoreographerDao;

@Service
public class ChoreographerService {

	@Autowired
	ChoreographerDao choreographerDao;

	public Choreographer addChoreographer(Choreographer choreographer) {
		return choreographerDao.save(choreographer);
	}


	public Choreographer getChoreographerById(int id) {
		return choreographerDao.getOne(id);
	}

	public List<Choreographer> getChoreographerByLocation(String location) {
		// TODO Auto-generated method stub
		return choreographerDao.getChoreographerByLocation(location);
	}


	public int updateChCount(String chName) {
		// TODO Auto-generated method stub
		return choreographerDao.updateChCount(chName);
	}

	public void deleteChoreographer(int choreographerId) {
		choreographerDao.deleteById(choreographerId);
	}
	
	public List<Choreographer> getAllChoreographer() {
		// TODO Auto-generated method stub
		return choreographerDao.findAll();
	}

	public List<Choreographer> getChoreographerByName(String chName) {
		// TODO Auto-generated method stub
		return choreographerDao.getChoreographerByName(chName);
	}

	
}
